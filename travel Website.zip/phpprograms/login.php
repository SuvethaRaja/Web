
<?php

//$uname1 = $_POST['uname1'];
//$upswd1 = $_POST['upswd1'];

/*if($_SERVER['REQUEST_METHOD']=="POST")
{
	

	if(!empty($uname1) && !empty($upswd1))
	{
		$query="SELECT * From register Where $uname1 ='$uname1' Limit 1";

		$result= mysqli_query($connection,$query);

		if($result && mysqli_num_rows($result)>0)
		{
			$myform= mysqli_fetch_assoc($result);

			if($myform['$upswd1']===$upswd1)
			{
				header("Location:home.php");
				die;
			}
		}
	}
}
*/


$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "booking";



// Create connection
$conn = mysqli_connect ($host, $dbusername, $dbpassword, $dbname);

if(mysqli_connect_errno()) {  
    die("Failed to connect with MySQL: ". mysqli_connect_error());  
}  


$name = $_POST['name'];  
$password = $_POST['password'];  
      
        //to prevent from mysqli injection  
        $name = stripcslashes($name);  
        $password = stripcslashes($password);  
        $name = mysqli_real_escape_string($conn, $name);  
        $password = mysqli_real_escape_string($conn, $password);  
      
        $sql = "SELECT * From regi Where name = '$name' and password = '$password'";  
        $result = mysqli_query($conn, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){  
            echo "<h1><center> Login successful </center></h1>";  
        }  
        else{  
            echo "<h1> Login failed. Invalid username or password.</h1>";  
        }     

?>

